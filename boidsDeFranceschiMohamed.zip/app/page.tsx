'use client'

import Image from "next/image";

import { useRef, useEffect, useState } from "react";

/*

function drawTriangle(ctx: CanvasRenderingContext2D, x: number, y: number){
  ctx.beginPath();
  ctx.moveTo(x, y-20);   // point 1
  ctx.lineTo(x+4, y-10);  // point 2
  ctx.lineTo(x-4, y-10); // point 3
  ctx.closePath();

  ctx.fillStyle = "blue";
  ctx.fill();
}
*/

class Entity {
  constructor(x, y, size, direction, velocity , color){
    this.x = x;
    this.y = y;
    this.size = size;
    this.direction = direction;
    this.velocity = velocity;
    this.color = color;
  }
  draw(ctx){
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate((this.direction * Math.PI) / 180); // conversion en radian d'ou la formule bzr
    ctx.beginPath();
    ctx.moveTo(0, -this.size / 2);
    ctx.lineTo(-this.size / 2, this.size / 2);
    ctx.lineTo(this.size / 2, this.size / 2);
    ctx.closePath();
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.restore();
  }
  nextFrame(deltaTime: number, entities){
    const rad = (this.direction * Math.PI) / 180;
    // Ici cos et sin sont inverser car 0 degres est en haut 
    // Et y cest -= et pas += par ce que le canvas + on dessend + y est grand
    this.x += Math.sin(rad) * this.velocity * deltaTime;
    this.y -= Math.cos(rad) * this.velocity * deltaTime;

    this.direction += Math.random() * 20 - 10;
    this.velocity += Math.random() * 20 - 10;
    if (this.velocity < 10){
      this.velocity = 10;
    }
  }
}

//
function createEntities(n: number, canvasWidth: number, canvasHeight: number){
  const entities: Entity[] = [];

  for(let i = 0; i<n; i++){
    const x = Math.random() * canvasWidth;
    const y = Math.random() * canvasHeight;
    const direction = Math.random() * 360;

    entities.push(new Entity(x, y, 10, direction, 20, "white"));
  }
  
  entities.forEach(other => {
    if (other === this) return;

    

  });
  
  return entities;
}

export default function Home() {

    
  const canvasRef = useRef<HTMLCanvasElement>(null);


  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    

    const entities = createEntities(50, canvas.width, canvas.height);
   

    let lastTime = 0;
    const targetFPS = 30;
    const frameInterval = 1000 / targetFPS;

    function gameLoop(currentTime: number) {
      if (ctx == null) return;
      if (canvas == null) return;

      if(currentTime - lastTime < frameInterval){
        requestAnimationFrame(gameLoop);
        return;
      }
      const deltaTime = (currentTime - lastTime) / 1000;
      lastTime = currentTime;

      ctx.fillStyle = "black";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

        
      entities.forEach(entity => entity.nextFrame(deltaTime, entities));

      entities.forEach(entity => entity.draw(ctx));

      requestAnimationFrame(gameLoop);
    }
    requestAnimationFrame(gameLoop);
    }, []);

  return (

     <canvas ref={canvasRef} id="canva" className="w-full h-full block" />

  );
}
